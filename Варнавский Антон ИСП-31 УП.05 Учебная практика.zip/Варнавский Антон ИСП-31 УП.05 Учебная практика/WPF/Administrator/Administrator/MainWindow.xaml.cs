﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Следующий_Click(object sender, RoutedEventArgs e)
        {
            int next = Theatre.SelectedIndex + 1;
            if (next >= Theatre.Items.Count)
                next = 0;
            Theatre.SelectedIndex = next;
        }
        private void Предыдущий_Click(object sender, RoutedEventArgs e)
        {
            int previous = Theatre.SelectedIndex - 1;
            if (previous < 0)
                previous = Theatre.Items.Count - 1;
            Theatre.SelectedIndex = previous;
        }

        private void Возврат_Click(object sender, RoutedEventArgs e)
        {
            int previous = Theatre.SelectedIndex - 4;
            if (previous < 0)
                previous = Theatre.Items.Count - 4;
            Theatre.SelectedIndex = previous;
        }

        private void Выход(object sender, RoutedEventArgs e)
        {
            int previous = Theatre.SelectedIndex - 6;
            if (previous < 0)
                previous = Theatre.Items.Count - 6;
            Theatre.SelectedIndex = previous;
        }
    }
}