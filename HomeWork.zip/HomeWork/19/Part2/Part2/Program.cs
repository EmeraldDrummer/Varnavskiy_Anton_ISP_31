﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Шаг 5: Переносим файл t2.txt из папки K1 в папку K2
            string folderPath = @"C:\temp";
            string sourceFilePath = Path.Combine(folderPath, "K1", "t2.txt");
            string destinationFilePath = Path.Combine(folderPath, "K2", "t2.txt");
            File.Move(sourceFilePath, destinationFilePath);

            // Шаг 6: Копируем файл t1.txt из папки K1 в папку K2
            sourceFilePath = Path.Combine(folderPath, "K1", "t1.txt");
            destinationFilePath = Path.Combine(folderPath, "K2", "t1.txt");
            File.Copy(sourceFilePath, destinationFilePath);

            // Шаг 7: Переименовываем папку K2 в All и удаляем папку K1
            string k1FolderPath = Path.Combine(folderPath, "K1");
            string k2FolderPath = Path.Combine(folderPath, "K2");
            string allFolderPath = Path.Combine(folderPath, "All");

            Directory.Move(k2FolderPath, allFolderPath); // Переименовываем папку K2 в All
            Directory.Delete(k1FolderPath, true); // Удаляем папку K1

            // Шаг 8: Выводим полную информацию о файлах в папке All
            Console.WriteLine("Файлы в папке All:");
            foreach (var file in Directory.GetFiles(allFolderPath))
            {
                Console.WriteLine(file);
            }
            Console.ReadKey();
        }
    }
}
