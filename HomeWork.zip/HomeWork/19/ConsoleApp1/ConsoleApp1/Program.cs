﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Шаг 1: Создаем папки K1 и K2 в директории C:\temp
            string folderPath = @"C:\temp";
            Directory.CreateDirectory(Path.Combine(folderPath, "K1"));
            Directory.CreateDirectory(Path.Combine(folderPath, "K2"));

            // Шаг 2: В папке K1 создаем файлы t1.txt и t2.txt с заданным текстом
            string text1 = "Иванов Иван Иванович, 1965 года рождения, место жительства г. Саратов";
            string text2 = "Петров Сергей Федорович, 1966 года рождения, место жительства г. Энгельс";

            File.WriteAllText(Path.Combine(folderPath, "K1", "t1.txt"), text1);
            File.WriteAllText(Path.Combine(folderPath, "K1", "t2.txt"), text2);

            // Шаг 3: В папке K2 создаем файл t3.txt и записываем в него содержимое файлов t1.txt и t2.txt
            string t1Content = File.ReadAllText(Path.Combine(folderPath, "K1", "t1.txt"));
            string t2Content = File.ReadAllText(Path.Combine(folderPath, "K1", "t2.txt"));
            File.WriteAllText(Path.Combine(folderPath, "K2", "t3.txt"), t1Content + Environment.NewLine + t2Content);

            // Шаг 4: Выводим информацию о созданных файлах
            Console.WriteLine("Созданные файлы:");
            Console.WriteLine("Папка K1 содержит файлы:");
            foreach (var file in Directory.GetFiles(Path.Combine(folderPath, "K1")))
            {
                Console.WriteLine(file);
            }
            Console.WriteLine("Папка K2 содержит файлы:");
            foreach (var file in Directory.GetFiles(Path.Combine(folderPath, "K2")))
            {
                Console.WriteLine(file);
            }
            Console.ReadKey();
        }
    }
}
