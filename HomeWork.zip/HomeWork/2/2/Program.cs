﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace _2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            string[] word = s.Split(' ');
            for (int i = 0; i < word.Count(); i++)
            {
                if (word[i].Length == 3)
                {
                    Console.WriteLine("Слово из 3 букв:");
                    Console.WriteLine(word[i]);
                }
            }
            Console.ReadLine();
        }
    }
}
