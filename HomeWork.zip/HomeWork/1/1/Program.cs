﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[] symbols = new char[15];
            int vowelsCount = 0;
            Console.WriteLine("Введите массив символов из 15 элементов:");
            string input = Console.ReadLine();
            if (input.Length != 15)
            {
                Console.WriteLine("Ошибка! Введите ровно 15 символов.");
            }
            symbols = input.ToCharArray();
            foreach (char symbol in symbols)
            {
                if (IsRussianVowel(symbol))
                {
                    vowelsCount++;
                }
            }
            Console.WriteLine($"Количество гласных русских букв в массиве: {vowelsCount}");
            Console.ReadKey();
        }
        static bool IsRussianVowel(char c)
        {
            string vowels = "аеёиоуыэюя";
            return vowels.Contains(char.ToLower(c));
        }
    }
}
