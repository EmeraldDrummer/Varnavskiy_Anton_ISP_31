﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = "Какая-то надпись";
            bool containsDigit = false;

            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    containsDigit = true;
                    break;
                }
            }

            if (containsDigit)
            {
                Console.WriteLine("В заданной строке есть цифра.");
            }
            else
            {
                Console.WriteLine("В заданной строке нет цифр.");
            }
            Console.ReadKey();
        }
    }
}
