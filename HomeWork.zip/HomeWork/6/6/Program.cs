﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = "Пример строки для подсчета символов";
            HashSet<char> uniqueChars = new HashSet<char>();

            foreach (char c in input)
            {
                if (!uniqueChars.Contains(c))
                {
                    uniqueChars.Add(c);
                }
            }

            int count = uniqueChars.Count;
            Console.WriteLine("Количество разных символов в строке: " + count);
            Console.ReadKey();
        }
    }
}
