﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[] charArray = new char[20];

            Console.WriteLine("Введите массив символов из 20 элементов (строчные буквы и пробелы):");
            string input = Console.ReadLine();

            if (input.Length != 20)
            {
                Console.WriteLine("Неверная длина массива. Пожалуйста, введите 20 символов.");
                return;
            }

            for (int i = 0; i < 20; i++)
            {
                charArray[i] = input[i];
            }

            string word = "";
            bool found = false;

            for (int i = 0; i < 20; i++)
            {
                if (char.IsLetter(charArray[i]))
                {
                    word += charArray[i];
                }
                else if (word.Length > 1 && word[0] == word[word.Length - 1])
                {
                    Console.WriteLine("Найдено слово: " + word);
                    found = true;
                    break;
                }
                else
                {
                    word = "";
                }
            }

            if (!found)
            {
                Console.WriteLine("Слово, начинающееся и заканчивающееся на одну и ту же букву, не найдено.");
            }
            Console.ReadKey ();
        }
    }
}
