﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = "Пример!строки!с!восклицательными!знаками!";
            string result = "";

            foreach (char c in input)
            {
                if (c == '!')
                {
                    result += ",";
                }
                result += c;
            }
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
